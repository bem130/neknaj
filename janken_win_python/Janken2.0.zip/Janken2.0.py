#Haruki1234
#jyanken version 2.0
#2020.05.28
#customize:public
#https://github.com/haruki1234/janken

#install package:numpy,DateTime
import math
import numpy
import time
import datetime
import os

filename = "jdata.csv"

if os.path.exists(filename)==False:
    with open(filename, mode='w', encoding='utf-8') as newfile:
        newfile.write("0,0,0,0,0,0,0,0")

with open(filename, 'r') as f:
    jd_list = f.read().split(",")

if len(jd_list)==1:
    with open(filename, mode='w', encoding='utf-8') as newfile:
        newfile.write("0,0,0,0,0,0,0,0")
    with open(filename, 'r') as f:
        jd_list = f.read().split(",")

jyan = ["グー　","チョキ","パー　"]

nowcunt = int(jd_list[0])
alltime = float(jd_list[1])
awin = int(jd_list[2])
bwin = int(jd_list[3])
aiko = int(jd_list[4])
g = int(jd_list[5])
t = int(jd_list[6])
p = int(jd_list[7])

def djyan():
    jnum = math.floor(numpy.random.rand()*len(jyan))
    return jyan[jnum]

def ljan(ahand,bhand):
    global awin
    global bwin
    global aiko
    global g
    global t
    global p
    if bshand=="グー　":
        g+=1
    if bshand=="チョキ":
        t+=1
    if bshand=="パー　":
        p+=1
    if ahand=="グー　":
        g+=1
        if bhand=="グー　":
            aiko+=1
            return "あいこ "
        if bhand=="チョキ":
            awin+=1
            return "aの勝ち"
        if bhand=="パー　":
            bwin+=1
            return "bの勝ち"
    if ahand=="チョキ":
        t+=1
        if bhand=="グー　":
            bwin+=1
            return "bの勝ち"
        if bhand=="チョキ":
            aiko+=1
            return "あいこ "
        if bhand=="パー　":
            awin+=1
            return "aの勝ち"
    if ahand=="パー　":
        p+=1
        if bhand=="グー　":
            awin+=1
            return "aの勝ち"
        if bhand=="チョキ":
            bwin+=1
            return "bの勝ち"
        if bhand=="パー　":
            aiko+=1
            return "あいこ "

print(" ジャンケン python ver2.0 public")
print(" 開始時刻:"+datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
print(" count,time\n")
start = time.time()

while True:
    nowcunt+=1
    ashand = djyan()
    bshand = djyan()
    ljan(ashand,bshand)
    netime = time.time()-start
    if nowcunt%10000000==0:
        with open(filename, mode='w', encoding='utf-8') as datafile:
            datafile.write(str(nowcunt)+","+str(alltime+netime)+","+str(awin)+","+str(bwin)+","+str(aiko)+","+str(g)+","+str(t)+","+str(p)+'\n')
            print("  "+str(nowcunt)+","+str(alltime+netime))