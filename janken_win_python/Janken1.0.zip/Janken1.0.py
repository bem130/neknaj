#Haruki1234
#jyanken version 2.0
#2021.05.08
#customize:public
#https://github.com/haruki1234/janken
#https://haruki1234.github.io/janken

#install package:numpy,DateTime

import math
import numpy
import time
import datetime

jyan = ["グー　","チョキ","パー　"]
nowcunt = 0

awin = 0
bwin = 0
aiko = 0

g = 0
t = 0
p = 0

def djyan():
    jnum = math.floor(numpy.random.rand()*len(jyan))
    return jyan[jnum]

def ljan(ahand,bhand):
    global awin
    global bwin
    global aiko
    global g
    global t
    global p
    if bshand=="グー　":
        g+=1
    if bshand=="チョキ":
        t+=1
    if bshand=="パー　":
        p+=1
    if ahand=="グー　":
        g+=1
        if bhand=="グー　":
            aiko+=1
            return "あいこ "
        if bhand=="チョキ":
            awin+=1
            return "aの勝ち"
        if bhand=="パー　":
            bwin+=1
            return "bの勝ち"
    if ahand=="チョキ":
        t+=1
        if bhand=="グー　":
            bwin+=1
            return "bの勝ち"
        if bhand=="チョキ":
            aiko+=1
            return "あいこ "
        if bhand=="パー　":
            awin+=1
            return "aの勝ち"
    if ahand=="パー　":
        p+=1
        if bhand=="グー　":
            awin+=1
            return "aの勝ち"
        if bhand=="チョキ":
            bwin+=1
            return "bの勝ち"
        if bhand=="パー　":
            aiko+=1
            return "あいこ "

print("\n#じゃんけん\n")
print("開始時刻:"+datetime.datetime.now().strftime('%Y年%m月%d日 %H:%M:%S'))
print("現在の回数,経過時間,aの勝ち数,bの勝ち数,あいこの数,グーを出した回数,チョキを出した回数,パーを出した回数")
with open('Jandata.txt', mode='a', encoding='utf-8') as datafile:
    datafile.write("\n\n"+datetime.datetime.now().strftime('%Y年%m月%d日 %H:%M:%S')+" 開始\n")
start = time.time()

while True:
    nowcunt+=1
    ashand = djyan()
    bshand = djyan()
    ljan(ashand,bshand)
    netime = time.time()-start
    if nowcunt%1000000==0:
        outputdata = str(nowcunt)+","+str(math.floor(netime*1000000)/1000000)+","+str(awin)+","+str(bwin)+","+str(aiko)+","+str(g)+","+str(t)+","+str(p)
        print(outputdata)
        if nowcunt%10000000==0:
            with open('Jandata.txt', mode='a', encoding='utf-8') as datafile:
                if datafile.write(outputdata+'\n'):
                    print("ファイルに出力しました!")