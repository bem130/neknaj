#Haruki1234
#jyanken version 3.2
#2020.05.29
#https://github.com/haruki1234/janken

#install package:numpy,DateTime,beautifulsoup4
import math
import numpy
import time
import datetime
import os
import configparser
import requests
from bs4 import BeautifulSoup

ver = "3.2"

if os.path.exists("jconfig"+ver+".ini")==False:
    with open("jconfig"+ver+".ini", mode='w', encoding='utf-8') as newfile:
        newfile.write("[file]\nfileoutput = yes\noutputfile = jdata.csv\noutputcount = 10000000\n[confver]\nconfnewversion = yes\n[mode]\nspeedmode = normal\nspeed = 0.001\noutputonebyone = no")

config = configparser.ConfigParser()
config.read('jconfig'+ver+'.ini', encoding='utf-8')

c_file = config["file"]
c_confver = config["confver"]
c_mode = config["mode"]

outputcnt = int(c_file["outputcount"])

if c_confver["confnewversion"]=="yes":
    v_load_url = "https://haruki1234.github.io/janken/jversion.ini"
    v_html = requests.get(v_load_url)
    v_datas = BeautifulSoup(v_html.content, "html.parser")
    v_data = str(v_datas)
    v_data = v_data.replace('\r', '')
    with open("get.jversion.ini", mode='w', encoding='utf-8') as v_datafile:
        v_datafile.write(v_data)
    getjversiondata = configparser.ConfigParser()
    getjversiondata.read('get.jversion.ini', encoding='utf-8')
    if float(ver)<float(getjversiondata["newversion"]["newest"]):
        print("新しいバージョンがあります! 新しいバージョンを使用することを推奨します。")
        print(" URL:https://haruki1234.github.io/janken/")
    else:
        print("お使いのバージョンは最新です!")

if c_file["fileoutput"]=="yes":
    filename = c_file["outputfile"]

    if os.path.exists(filename)==False:
        with open(filename, mode='w', encoding='utf-8') as newfile:
            newfile.write("0,0,0,0,0,0,0,0")

    with open(filename, 'r') as f:
        jd_list = f.read().split(",")

    if len(jd_list)==1:
        with open(filename, mode='w', encoding='utf-8') as newfile:
            newfile.write("0,0,0,0,0,0,0,0")
        with open(filename, 'r') as f:
            jd_list = f.read().split(",")

    nowcunt = int(jd_list[0])
    alltime = float(jd_list[1])
    awin = int(jd_list[2])
    bwin = int(jd_list[3])
    aiko = int(jd_list[4])
    g = int(jd_list[5])
    t = int(jd_list[6])
    p = int(jd_list[7])
else:
    nowcunt = 0
    alltime = 0
    awin = 0
    bwin = 0
    aiko = 0
    g = 0
    t = 0
    p = 0

jyan = ["グー　","チョキ","パー　"]

def djyan():
    jnum = math.floor(numpy.random.rand()*len(jyan))
    return jyan[jnum]

def ljan(ahand,bhand):
    global awin
    global bwin
    global aiko
    global g
    global t
    global p
    if bshand=="グー　":
        g+=1
    if bshand=="チョキ":
        t+=1
    if bshand=="パー　":
        p+=1
    if ahand=="グー　":
        g+=1
        if bhand=="グー　":
            aiko+=1
            return "あいこ "
        if bhand=="チョキ":
            awin+=1
            return "aの勝ち"
        if bhand=="パー　":
            bwin+=1
            return "bの勝ち"
    if ahand=="チョキ":
        t+=1
        if bhand=="グー　":
            bwin+=1
            return "bの勝ち"
        if bhand=="チョキ":
            aiko+=1
            return "あいこ "
        if bhand=="パー　":
            awin+=1
            return "aの勝ち"
    if ahand=="パー　":
        p+=1
        if bhand=="グー　":
            awin+=1
            return "aの勝ち"
        if bhand=="チョキ":
            bwin+=1
            return "bの勝ち"
        if bhand=="パー　":
            aiko+=1
            return "あいこ "

print(" ジャンケン python ver"+ver+"")
if c_file["fileoutput"]!="yes":
    print(" 注意:ファイルへの出力がOFFになっているのでプログラムをリセットするとデータもリセットされます。\n jconfig"+ver+".iniファイルのfileoutputをyesにすることを推奨します。")
print(" 開始時刻:"+datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S"))
print(" count,time\n")
start = time.time()


if c_mode["speedmode"]=="normal":
    if c_file["fileoutput"]=="yes":
        while True:
            nowcunt+=1
            ashand = djyan()
            bshand = djyan()
            ljan(ashand,bshand)
            netime = time.time()-start
            if nowcunt%outputcnt==0:
                with open(filename, mode='w', encoding='utf-8') as datafile:
                    datafile.write(str(nowcunt)+","+str(alltime+netime)+","+str(awin)+","+str(bwin)+","+str(aiko)+","+str(g)+","+str(t)+","+str(p)+'\n')
                    print("  "+str(nowcunt)+","+str(alltime+netime))
    else:
        while True:
            nowcunt+=1
            ashand = djyan()
            bshand = djyan()
            ljan(ashand,bshand)
            netime = time.time()-start
            if nowcunt%outputcnt==0:
                print("  "+str(nowcunt)+","+str(alltime+netime)+","+str(awin)+","+str(bwin)+","+str(aiko)+","+str(g)+","+str(t)+","+str(p))
elif c_mode["speedmode"]=="customize":
    if c_file["fileoutput"]=="yes":
        while True:
            time.sleep(float(c_mode["speed"]))
            nowcunt+=1
            ashand = djyan()
            bshand = djyan()
            ljan(ashand,bshand)
            netime = time.time()-start
            if c_mode["outputonebyone"]=="yes":
                print("   "+str(nowcunt)+","+str(alltime+netime))
            if nowcunt%outputcnt==0:
                with open(filename, mode='w', encoding='utf-8') as datafile:
                    datafile.write(str(nowcunt)+","+str(alltime+netime)+","+str(awin)+","+str(bwin)+","+str(aiko)+","+str(g)+","+str(t)+","+str(p)+'\n')
                    print("  "+str(nowcunt)+","+str(alltime+netime)+","+str(awin)+","+str(bwin)+","+str(aiko))
    else:
        while True:
            time.sleep(float(c_mode["speed"]))
            nowcunt+=1
            ashand = djyan()
            bshand = djyan()
            ljan(ashand,bshand)
            netime = time.time()-start
            if c_mode["outputonebyone"]=="yes":
                print("   "+str(nowcunt)+","+str(alltime+netime))
            if nowcunt%outputcnt==0:
                print("  "+str(nowcunt)+","+str(alltime+netime)+","+str(awin)+","+str(bwin)+","+str(aiko)+","+str(g)+","+str(t)+","+str(p))